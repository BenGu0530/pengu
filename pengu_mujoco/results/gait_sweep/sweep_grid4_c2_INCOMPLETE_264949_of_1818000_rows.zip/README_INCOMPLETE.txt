GRID-4 config c2 -- INCOMPLETE / MACHINE B DECOMMISSIONED
=========================================================
This is a PARTIAL sweep. c2 is NOT finished. Do not treat this as ship-back
data and do not merge it into the paper table.

config          c2  (kappa=0, COM ratio 1.20)
rows present    264,949 of 1,818,000   (14.57%)
protocol        staged-K amendment, DR_K=1 (K=1 map sweep)
machine         B -- Ryzen 7 5800H / WSL2 Ubuntu 22.04
stopped         2026-08-19, sweep halted deliberately; machine retired from the
                fleet (CPU too slow relative to the other boxes)
schema          12 cols: freq,hip_phi,leg_amp,hip_amp,hip_off,mu,
                pass_rate,surv_rate,net_fwd_mean,net_fwd_min,slip_mean,head_mean

Integrity (verified after the shards were stopped, before packing):
  - every line has exactly 12 fields
  - header row present and correct
  - 0 duplicate 6-tuples

TO RESUME c2 ON ANOTHER MACHINE
-------------------------------
Do NOT use this zip. The same data is committed alongside it as

  results/gait_sweep/sweep_grid4_c2_freq_hip_phi_leg_amp_hip_amp_hip_off_mu.csv.gz

which run_sweep.sh recovers automatically: on a fresh clone,

  DR_K=1 GRID3_PY=$PWD/.sweep_venv/bin/python bash physics/run_sweep.sh c2

gunzips it and resumes from row 264,949 by axis-tuple. This zip exists only as a
clearly-labelled human-readable copy.

An earlier K=5 partial (22,496 rows) is archived separately as
...csv.k5partial.gz in commit 725f34a. K values are never mixed in one CSV.
